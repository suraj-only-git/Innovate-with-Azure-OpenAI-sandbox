# Chat Copilot setup scripts - Local deployment

To use these scripts, please follow the quick-start guide found [here](../README.md).

# Welcome to the Copilot Chat Community!

Below are some ways that you can get involved in the SK Community.

## Engage on Github

File issues, submit PRs, and provide feedback and ideas to what you'd like to see from Copilot Chat.
We do our best to respond to each submission.

# Ambush

## Overview

 When a small outpost is ambushed, a US Army squad must take the battle below ground on a high-stakes mission in a new type of warfare the likes of which they have never seen.

## Details

**Release Date:** 2023-02-24

**Genres:** Action, War, Thriller

**Popularity:** 386.559

**Vote Average:** 5.8

**Keywords:** 


# Indiana Jones and the Dial of Destiny

## Overview

 Finding himself in a new era, approaching retirement, Indy wrestles with fitting into a world that seems to have outgrown him. But as the tentacles of an all-too-familiar evil return in the form of an old rival, Indy must don his hat and pick up his whip once more to make sure an ancient and powerful artifact doesn't fall into the wrong hands.

## Details

**Release Date:** 2023-06-28

**Genres:** Adventure, Action, Fantasy

**Popularity:** 740.388

**Vote Average:** 6.5

**Keywords:** feminism, sequel, flashback, prologue, knife fight, archaeologist, adventurer, 1960s, relic hunter


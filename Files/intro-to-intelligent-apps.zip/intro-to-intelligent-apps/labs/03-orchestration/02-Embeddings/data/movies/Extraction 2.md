# Extraction 2

## Overview

 Tasked with extracting a family who is at the mercy of a Georgian gangster, Tyler Rake infiltrates one of the world's deadliest prisons in order to save them. But when the extraction gets hot, and the gangster dies in the heat of battle, his equally ruthless brother tracks down Rake and his team to Vienna, in order to get revenge.

## Details

**Release Date:** 2023-06-09

**Genres:** Action, Thriller

**Popularity:** 1422.453

**Vote Average:** 7.6

**Keywords:** mercenary, sequel, rescue mission, long take, based on graphic novel


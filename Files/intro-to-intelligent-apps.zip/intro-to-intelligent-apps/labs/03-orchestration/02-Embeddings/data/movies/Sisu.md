# Sisu

## Overview

 Deep in the wilderness of Lapland, Aatami Korpi is searching for gold but after he stumbles upon Nazi patrol, a breathtaking and gold-hungry chase through the destroyed and mined Lapland wilderness begins.

## Details

**Release Date:** 2023-01-27

**Genres:** Action, War

**Popularity:** 520.792

**Vote Average:** 7.5

**Keywords:** world war ii, nordic mythology, lapland, finnish mythology


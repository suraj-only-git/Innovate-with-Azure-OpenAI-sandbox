# Guy Ritchie's The Covenant

## Overview

 During the war in Afghanistan, a local interpreter risks his own life to carry an injured sergeant across miles of grueling terrain.

## Details

**Release Date:** 2023-04-19

**Genres:** War, Action, Thriller

**Popularity:** 544.105

**Vote Average:** 7.8

**Keywords:** ambush, interpreter, afghanistan, afghanistan war (2001- ), rescue, war


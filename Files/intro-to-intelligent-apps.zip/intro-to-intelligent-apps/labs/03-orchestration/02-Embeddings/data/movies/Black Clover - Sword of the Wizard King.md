# Black Clover: Sword of the Wizard King

## Overview

 As a lionhearted boy who can’t wield magic strives for the title of Wizard King, four banished Wizard Kings of yore return to crush the Clover Kingdom.

## Details

**Release Date:** 2023-06-16

**Genres:** Animation, Fantasy, Action, Adventure

**Popularity:** 336.12

**Vote Average:** 8.4

**Keywords:** magic, demon, wizard, shounen, anime


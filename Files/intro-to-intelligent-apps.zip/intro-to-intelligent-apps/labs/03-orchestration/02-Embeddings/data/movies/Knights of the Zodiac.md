# Knights of the Zodiac

## Overview

 When a headstrong street orphan, Seiya, in search of his abducted sister unwittingly taps into hidden powers, he discovers he might be the only person alive who can protect a reincarnated goddess, sent to watch over humanity. Can he let his past go and embrace his destiny to become a Knight of the Zodiac?

## Details

**Release Date:** 2023-04-27

**Genres:** Fantasy, Action, Adventure

**Popularity:** 3355.755

**Vote Average:** 6.5

**Keywords:** superhero, based on manga, live action anime


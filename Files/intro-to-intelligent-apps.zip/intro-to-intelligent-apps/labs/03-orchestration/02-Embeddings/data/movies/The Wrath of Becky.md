# The Wrath of Becky

## Overview

 Two years after she escaped a violent attack on her family, 16-year-old Becky attempts to rebuild her life in the care of an older woman -- a kindred spirit named Elena. However, when a violent group known as the Noble Men break into their home, attack them and take their beloved dog, Becky must return to her old ways to protect herself and her loved ones.

## Details

**Release Date:** 2023-05-26

**Genres:** Action, Horror, Thriller

**Popularity:** 759.396

**Vote Average:** 6.8

**Keywords:** machete, sequel, revenge, murder, gore, diner, dog, blood, terrorists


# Ant-Man and the Wasp: Quantumania

## Overview

 Super-Hero partners Scott Lang and Hope van Dyne, along with with Hope's parents Janet van Dyne and Hank Pym, and Scott's daughter Cassie Lang, find themselves exploring the Quantum Realm, interacting with strange new creatures and embarking on an adventure that will push them beyond the limits of what they thought possible.

## Details

**Release Date:** 2023-02-15

**Genres:** Action, Adventure, Science Fiction

**Popularity:** 525.418

**Vote Average:** 6.5

**Keywords:** hero, ant, sequel, superhero, based on comic, family, superhero team, aftercreditsstinger, duringcreditsstinger


# Fast X

## Overview

 Over many missions and against impossible odds, Dom Toretto and his family have outsmarted, out-nerved and outdriven every foe in their path. Now, they confront the most lethal opponent they've ever faced: A terrifying threat emerging from the shadows of the past who's fueled by blood revenge, and who is determined to shatter this family and destroy everything—and everyone—that Dom loves, forever.

## Details

**Release Date:** 2023-05-17

**Genres:** Action, Crime, Thriller

**Popularity:** 3283.417

**Vote Average:** 7.3

**Keywords:** sequel, revenge, racing, family, cars


# John Wick: Chapter 4

## Overview

 With the price on his head ever increasing, John Wick uncovers a path to defeating The High Table. But before he can earn his freedom, Wick must face off against a new enemy with powerful alliances across the globe and forces that turn old friends into foes.

## Details

**Release Date:** 2023-03-22

**Genres:** Action, Thriller, Crime

**Popularity:** 1437.077

**Vote Average:** 7.9

**Keywords:** new york city, martial arts, hitman, sequel, organized crime, osaka, japan, aftercreditsstinger, hunted, professional assassin, neo-noir, berlin


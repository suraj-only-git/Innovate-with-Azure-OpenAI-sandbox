# Los bastardos

## Overview

 

## Details

**Release Date:** 2023-03-30

**Genres:** Action, Thriller, Crime, Drama

**Popularity:** 431.075

**Vote Average:** 6.1

**Keywords:** 


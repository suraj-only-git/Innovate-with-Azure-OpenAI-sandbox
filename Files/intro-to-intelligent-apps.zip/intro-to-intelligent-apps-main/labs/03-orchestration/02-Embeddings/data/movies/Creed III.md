# Creed III

## Overview

 After dominating the boxing world, Adonis Creed has been thriving in both his career and family life. When a childhood friend and former boxing prodigy, Damian Anderson, resurfaces after serving a long sentence in prison, he is eager to prove that he deserves his shot in the ring. The face-off between former friends is more than just a fight. To settle the score, Adonis must put his future on the line to battle Damian — a fighter who has nothing to lose.

## Details

**Release Date:** 2023-03-01

**Genres:** Drama, Action

**Popularity:** 433.823

**Vote Average:** 7.2

**Keywords:** philadelphia, pennsylvania, husband wife relationship, deaf, sports, sequel, orphan, former best friend, ex-con, childhood friends, juvenile detention center, boxing, prodigy


# Confidential Informant

## Overview

 During a crack epidemic two narcotics agents hunting for a cop killer. Hoping for leads, Moran and Thorton pay off a junkie informant. To provide for his wife and son, Moran involves the stool pigeon in a deadly scheme. This causes the partners to come under the scrutiny of a suspicious internal affairs agent.

## Details

**Release Date:** 2023-06-27

**Genres:** Mystery, Thriller, Action

**Popularity:** 408.062

**Vote Average:** 6.4

**Keywords:** gritty, crime


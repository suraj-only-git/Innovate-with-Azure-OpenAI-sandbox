# iNumber Number: Jozi Gold

## Overview

 When an undercover cop is tasked with investigating a historic gold heist in Johannesburg, he’s forced to choose between his conscience and the law.

## Details

**Release Date:** 2023-06-23

**Genres:** Crime, Action, Thriller

**Popularity:** 719.085

**Vote Average:** 6.3

**Keywords:** 


# Transformers: Rise of the Beasts

## Overview

 When a new threat capable of destroying the entire planet emerges, Optimus Prime and the Autobots must team up with a powerful faction known as the Maximals. With the fate of humanity hanging in the balance, humans Noah and Elena will do whatever it takes to help the Transformers as they engage in the ultimate battle to save Earth.

## Details

**Release Date:** 2023-06-06

**Genres:** Action, Adventure, Science Fiction

**Popularity:** 1301.343

**Vote Average:** 7.3

**Keywords:** peru, alien, end of the world, based on cartoon, based on toy, robot, duringcreditsstinger, 1990s, brother brother relationship


# The Flash

## Overview

 When his attempt to save his family inadvertently alters the future, Barry Allen becomes trapped in a reality in which General Zod has returned and there are no Super Heroes to turn to. In order to save the world that he is in and return to the future that he knows, Barry's only hope is to race for his life. But will making the ultimate sacrifice be enough to reset the universe?

## Details

**Release Date:** 2023-06-13

**Genres:** Science Fiction, Action, Adventure

**Popularity:** 786.283

**Vote Average:** 6.7

**Keywords:** secret identity, hero, superhero, based on comic, superhuman, super power, aftercreditsstinger, butterfly effect, dc extended universe (dceu), superhuman abilities, loss of mother


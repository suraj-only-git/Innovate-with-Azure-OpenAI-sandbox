﻿// Copyright (c) Microsoft. All rights reserved.

namespace Microsoft.SemanticKernel.Connectors.Pinecone;

internal enum OperationType
{
    Upsert,
    Update,
    Skip
}

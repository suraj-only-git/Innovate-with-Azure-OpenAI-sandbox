# Semantic Kernel feature matrix by language

This document has been moved to the Semantic Kernel Documentation site. You can find it by navigating to the [Supported Languages](https://learn.microsoft.com/en-us/semantic-kernel/get-started/supported-languages) page.

To make an update on the page, file a PR on the [docs repo.](https://github.com/MicrosoftDocs/semantic-kernel-docs/blob/main/semantic-kernel/get-started/supported-languages.md)

# Semantic Kernel Oobabooga AI Connector

This connector have moved, please go [here](https://github.com/MyIntelligenceAgency/semantic-fleet) for more information.
